<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//error_reporting(0);
//ini_set('display_errors', 0);
class Controller extends CI_Controller {
function __construct() {
        parent::__construct();
		$this->load->model('Model');
		$this->load->database();
		//$this->load->library('session');
}

	public function home(){
		// GET all records
		$this->db->select('id , name, number, hobby, cat, picture');
		$query = $this->db->get('user');
		$getrecords = $query->result();
		$arraypass = array(
		'all_records' => $getrecords
		);
		$this->load->view('header');
		$this->load->view('index',$arraypass);
	}
// ADD RECORDS
	public function add()
	{
		// hobbies
		$this->db->select('hobby_id, hobby');
		$query = $this->db->get('hobby');
		$gethobby = $query->result();
		
		// cattegory
		$this->db->select('cat_id , cat_name');
		$query1 = $this->db->get('category');
		$getcats = $query1->result();
		
		$arraypass = array(
		'all_hobbiles' => $gethobby,
		'all_cats' => $getcats
		);
		$this->load->view('header');
		$this->load->view('add',$arraypass);
	}
	public function add_action(){
		$this->Model->add_action_model();
	}
//DELETE RECORDS	
	public function deleterecords(){
		$delete = $this->Model->deleterecords_model();
		if($delete==true){
				
				$this->session->set_flashdata('delete_records', 'Records deleted!');
				redirect('/');
			}
			else{
				$this->session->set_flashdata('delete_error', 'Somethig went wrong!');
				redirect('/');
			}
	}

//EDIT USER		
	public function edit_action(){
		$this->Model->edit_action_model();
	}
}
