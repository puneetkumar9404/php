<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model extends CI_Model {
// ADD RECORDS
	public function add_action_model()
	{
		$username = $this->input->post('username');
		$contact = $this->input->post('contact');
		$hobby = implode(",", $this->input->post('hobby'));
		$category = $this->input->post('category');
		
		$config['upload_path']   = './pictures'; 
		$config['allowed_types']='gif|jpg|png|jpeg|webp'; 
		$config['encrypt_name'] = TRUE;
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		if($this->upload->do_upload("picture")){
        $data = array('upload_data' => $this->upload->data()); 
			
		$image_name=$data['upload_data']['file_name'];
				
	}
	else{
		$image_name="";
	}
	$image_array=array(
	'name' => $username,
	'number' => $contact,
	'hobby' => $hobby,
	'cat' => $category,
	'picture' => $image_name
	);
	$insert = $this->db->insert('user',$image_array);
	if($insert==true){
		echo 'true';
	}
	else{
		echo 'false';
	}
	}
// BULK DELETE RECORDS	
	public function deleterecords_model(){
		$record_ids = explode(",", $this->input->post('record_ids'));
		echo '<pre>';
		print_r($record_ids);
		echo '</pre>'; 
		foreach($record_ids as $id){
			$this -> db -> where('id', $id);
			$this -> db -> delete('user');
		}
		return true;
			
	}
// Edit Profile
	public function edit_action_model(){
		$id = $this->input->post('id');
		$username = $this->input->post('username');
		$contact = $this->input->post('contact');
		$hobby =  $this->input->post('habby_id');
		$category = $this->input->post('category');
		$uploadedfile = $this->input->post('uploadedfile');

		$config['upload_path']   = './pictures'; 
		$config['allowed_types']='gif|jpg|png|jpeg|webp'; 
		$config['encrypt_name'] = TRUE;
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		if($this->upload->do_upload("picture")){
        $data = array('upload_data' => $this->upload->data()); 
			
		$image_name=$data['upload_data']['file_name'];
				
		}
		else{
			$image_name=$uploadedfile;
		}

		$data=array(
		'name' => $username,
		'number' => $contact,
		'hobby' => $hobby,
		'cat' => $category,
		'picture' => $image_name
		);
	 $this->db->where('id', $id);
		$update =  $this->db->update('user', $data);
		//print_r($this->db->last_query());
	if($update==true){
				echo 'updated';
			}
			else{
				echo 'notupdated';
			}
	
	}
}
