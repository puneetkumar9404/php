<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div id="container">
<div class="row">
<div class="col-sm-3"></div>
<div class="col-sm-6">
	<div id="body">
	<div class="success"></div>
	<div class="error"></div>
	<h2>Add New User</h2>
		<form action="" method="post" id="formid" enctype="multipart/form-data">
  <div class="row">
    <div class="col-25">
      <label for="fname">Name</label>
    </div>
    <div class="col-75">
      <input type="text" name="username" id="username"><span id="name_msg" class="valid"></span>
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label for="lname">Contact</label>
    </div>
    <div class="col-75">
      <input type="text" name="contact" id="contact"><span id="contact_msg" class="valid"></span>
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label for="country">Hobby</label>
    </div>
    <div class="col-75">
	<?php if(isset($all_hobbiles)){ 
		foreach($all_hobbiles as $gethobbies){
			echo '<input type="checkbox" name="hobby[]" id="hobby" value="'.$gethobbies->hobby.'">'. $gethobbies->hobby.''; } } 
			?>
	
      <!--<select name="hobby" id="hobby">
		<option value="0">Select Hobby</option>
		<?php if(isset($all_hobbiles)){ 
		foreach($all_hobbiles as $gethobbies){
			echo '<option value="'.$gethobbies->hobby.'">'.$gethobbies->hobby.'</option>'; } } 
			?>
		</select>--><span id="hobby_msg" class="valid"></span>
    </div>
  </div>
    <div class="row">
    <div class="col-25">
      <label for="country">Category</label>
    </div>
    <div class="col-75">
      <select name="category" id="category">
		<option value="0">Select Category</option>
		<?php if(isset($all_cats)){ 
		foreach($all_cats as $getcats){
			echo '<option value="'.$getcats->cat_name.'">'.$getcats->cat_name.'</option>'; } } 
			?>
		</select><span id="category_msg" class="valid"></span>
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label for="subject">Picture</label>
    </div>
    <div class="col-75">
      <input type="file" name="picture" id="picture"><span id="picture_msg" class="valid"></span>
    </div>
  </div>
  <br>
  <div class="row">
    <input type="submit" name="save" id="save" value="Add">
  </div>
  </form>
	</div>
</div>
<div class="col-sm-3"></div>
</div>
</div>

</body>
</html>
