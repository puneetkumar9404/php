<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Home</title>
	 <link rel="stylesheet" href="<?php echo base_url(); ?>assets/style.css">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<script>
	function detlete(id){
		$('#deleterecord').modal('show');
		$('#record_ids').val(id);
	}
	
	function bulkdelete(){
		var bulkcheck = $('.deletechk').val();
		 if ($('.deletechk').filter(':checked').length < 1){
        $('#bulk_validation').text('You must check at least one box!');
 return false;
 }
 else{
	 $('#deleterecord').modal('show');
	 $('#bulk_validation').hide();
	  var valu = [];
        $('.deletechk:checkbox:checked').each(function(i){
          valu[i] = $(this).val();
        });
	$('#record_ids').val(valu);
            return true;
 }

	}
	</script>
<!--====== ADD =============-->
<script>
$(document).ready(function(){
  $("#formid").submit(function(e){
  e.preventDefault();
  var name = $('#username').val();
  var contact = $('#contact').val();
  var hobby = $('#hobby').val();
  var category = $('#category').val();
  var picture = $('#picture').val();
  
  var name_msg = "";
  var contact_msg = "";
  if(name=="" || name==null){
	  $('#name_msg').text('Name is required.');
	  return false;
  }
  else if(contact=="" || contact==null){
	  $('#contact_msg').text('Contact is required.');
	  return false;
  }
  		 else if ($('input:checkbox').filter(':checked').length < 1){
        $('#hobby_msg').text('You must check at least one box!');
 return false;
 }
  else if(category==0){
	  $('#category_msg').text('Please select category.');
	  return false;
  }
  else if(picture==""){
	  $('#picture_msg').text('Please upload picture.');
	  return false;
  }
  else{
	  $('#name_msg').hide();
	  $('#contact_msg').hide();
	  $('#hobby_msg').hide();
	   $('#category_msg').hide();
	   $('#picture_msg').hide();
	  $.ajax({
             url:'<?php echo site_url('add_action'); ?>',
             type:"post",
             data:new FormData(this),
             processData:false,
             contentType:false,
             cache:false,
             async:false,
              success: function(data){
				  $("#formid")[0].reset();
				if(data=='true'){
					$('.error').hide();
					$('.success').show();
					$('.success').text('User add successfully.');
					location.href = "<?php echo site_url(); ?>";
				}
				if(data=='false'){
					$("#formid")[0].reset();
					$('.error').show();
					$('.success').hide();
					$('.error').text('Something went wrong.');
				}
              }
	   
         });
	  return true;
  }
  });
});
//EDIT
function edit(id){
	$('.tr-'+id).hide();
	$('.getacess-'+id).show();
}

$(document).ready(function(){
  $(".updateform").submit(function(e){
	  e.preventDefault();
   var id=$(this).attr('id');
   // alert(id);
   var username = $('#username-'+id).val();
   var contact = $('#contact-'+id).val();
   var hobbys = $('.hobbys-'+id).val();
  // alert(username);
   var category = $('#category-'+id).val();
   var valu = [];
        $('.hobbys-'+id+':checkbox:checked').each(function(i){
          valu[i] = $(this).val();
        });
		//alert(valu);
		$('#habby_id-'+id).val(valu);
$.ajax({
              url:'<?php echo site_url('edit_action'); ?>',
              type:"post",
//data:{'id':id,'username':username,'contact':contact,'hobbys':valu,'category':category },
data:new FormData(this),
              processData:false,
              contentType:false,
              cache:false,
              async:false,
               success: function(data){
//alert(data);
//location.reload();
 var spinner = "<img src='http://i.imgur.com/pKopwXp.gif' alt='loading...' />";

  // specify the server/url you want to load data from
  var url = "http://127.0.0.1/puneettest/";
$("#container").html(spinner).load(url);
					//$('.tables').html(data);
		 			$("tr").load(location.href + " tr");
               }
	   
         });
  });
  });
</script>	
</head>
<body>

