<?php defined('BASEPATH') OR exit('No direct script access allowed');
// Get all hobbies
$query_allhobbies = $this->db->query("SELECT * FROM hobby");
$all_data=$query_allhobbies->result_array();
// Get all categories		
$query_allcategories = $this->db->query("SELECT cat_name FROM category");
$all_data_cats = $query_allcategories->result_array();		
?>
<div id="container">
<div class="row">
<div class="col-sm-12">
<span id="bulk_validation"></span>
<?php 
$update_records = $this->session->flashdata('update_records');
$success = $this->session->flashdata('delete_records');
$error = $this->session->flashdata('delete_error');
if(isset($success)){
	echo $success;
}
if(isset($error)){
	echo $error;
}

?>
<div class="buttons"><a class="addnew" href="<?php echo base_url('add'); ?>">Add New</a> | <a class="bulkdelete" href="javascript:;" onclick="return bulkdelete();">Bulk Delete</a></div>
<div class="allrecords">
<!-- <form action="" method="post" id="updateform"> -->
<table border="1" class="tables">
<tr>
<th>Srno</th><th>Select</th><th>Name</th><th>Contact</th><th>Hobby</th><th>Category</th><th>Picture</th><th>Edit</th>
</tr>
<?php if(isset($all_records)){
	$i = 1;
foreach($all_records as $data){ 
?>
<tr class="tr-<?php echo $data->id; ?>">
<td><?php echo $i++; ?></td>
<td><input type="checkbox" name="deletechk" class="deletechk" id="deletechk" value="<?php echo $data->id; ?>"></td>
<td><?php echo $data->name; ?></td>
<td><?php echo $data->number; ?></td>
<td><?php echo $data->hobby; ?></td>
<td><?php echo $data->cat; ?></td>
<td><img style="width:50px; height:50px;" src="<?php echo base_url(); ?>/pictures/<?php echo $data->picture; ?>"></td>
<td><a href="javascript:;" onclick="return edit(<?php echo $data->id; ?>);" id="edits">Edit</a> | <a href="javascript:;" onclick="return detlete(<?php echo $data->id; ?>);">Delete</a></td>
</tr>
<tr class="getacess-<?php echo $data->id; ?> tr-s" style="display:none;">
<?php $query = $this->db->query("SELECT id,name,number,hobby,cat,picture FROM user WHERE id=".$data->id."");
		$edit_data=$query->row();
		?>
<form id="<?php echo $data->id; ?>" method="post" class="updateform" enctype="multipart/form-data">
	<td></td><td></td>
	<td><input type="text" name="username" id="username-<?php echo $data->id; ?>" value="<?php echo $edit_data->name; ?>"></td>
	<td><input type="text" name="contact" id="contact-<?php echo $data->id; ?>" value="<?php echo $edit_data->number; ?>"><input type="hidden" name="id" id="id" value="<?php echo $edit_data->id; ?>"></td>
	<td>
	<?php $hobbies = explode(",",$edit_data->hobby);
				//print_r($hobbies);
	foreach($all_data as $gethobby){
	$checked = (in_array( $gethobby['hobby'], $hobbies)) ? 'checked="checked"' : '';
	?>
	<input type="checkbox" name="hobbys[]" class="hobbys-<?php echo $edit_data->id; ?>" value="<?php echo $gethobby['hobby']; ?>" <?php if (in_array($gethobby['hobby'], $hobbies)) { echo 'checked';} ?>> <?php echo $gethobby['hobby']; ?>
<?php	} ?>
	</td>
	<td>
	<input type="hidden" id="habby_id-<?php echo $edit_data->id; ?>" name="habby_id">
	<select name="category" id="category-<?php echo $data->id; ?>">
		<?php foreach($all_data_cats as $getcats){
			if($getcats['cat_name']==$edit_data->cat){
				$cat = "selected";
			}
		echo '<option value="'.$getcats['cat_name'].'" '.$cat.'>'.$getcats['cat_name'].'</option>';
			} ?>
	</select></td>
	<td><input type="file" name="picture" value=""><img style="width:50px; height:50px;" src="<?php echo base_url(); ?>/pictures/<?php echo $edit_data->picture; ?>">
	<input type="hidden" name="uploadedfile" id="uploadedfile-<?php echo $edit_data->id; ?>" value="<?php echo $edit_data->picture; ?>">
	</td>
	<td><input type="submit" attr="<?php echo $edit_data->id; ?>" name="update" value="Update" class="edit-btn update_data"></td>
	</form>
</tr>
<?php } } ?>
</table>
<!--</form>-->
</div>
</div>

</div>

<!--======== MODAL ==========-->
  <div class="modal fade" id="deleterecord" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
	  <form action="<?php echo base_url('deleterecords'); ?>" method="post">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Delete Record</h4>
        </div>
        <div class="modal-body">
		
          <p>Want to delete?</p>
		  <input type="hidden" name="record_ids" id="record_ids" value="">
		  
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		  <button type="submit" class="btn btn-default" name="delete">Yes</button>
        </div>
		
      </div>
      
    </div>
  </div>
</body>
</html>
